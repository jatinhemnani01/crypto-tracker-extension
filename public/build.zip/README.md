# Crypto Tracker

It's a simple extension where you can see live prices of Top CryptoCurrencies without doing anything.

## Built With Svelte

### [Github](https://github.com/jatinhemnani01/crypto-tracker "Github")

### [Buy Me A Coffee](https://www.buymeacoffee.com/jatinhemnani01 "Buy Me A Coffee")
